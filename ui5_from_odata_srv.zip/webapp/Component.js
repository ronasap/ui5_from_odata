jQuery.sap.declare("ui5_from_odata_srv.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ui5_from_odata_srv.Component", {
	metadata: {
		"manifest": "json"
	}
});